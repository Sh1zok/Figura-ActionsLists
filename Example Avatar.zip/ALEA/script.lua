page = action_wheel:newPage()
action_wheel:setPage(page)

croppingDemo = page:newActionList()
    :title("The cropping and visualSize")
    :item("minecraft:map")
    :actionList({
        {title = "Hi!", onSelect = function() croppingDemo:visualSize(7) end},
        {title = "This"},
        {title = "list"},
        {title = "is"},
        {title = "intentionally"},
        {title = "made"},
        {title = "so"},
        {title = "long"},
        {title = "show"},
        {title = "its"},
        {title = "cropping."},
        {title = "The"},
        {title = "cropping"},
        {title = "is"},
        {title = "needed"},
        {title = "to"},
        {title = "create"},
        {title = "very"},
        {title = "long"},
        {title = "lists"},
        {title = "of"},
        {title = "actions"},
        {title = "and"},
        {title = "have"},
        {title = "access"},
        {title = "to"},
        {title = "each"},
        {title = "action"},
        {title = "in"},
        {title = "them."},
        {title = "The"},
        {title = "list"},
        {title = "size"},
        {title = "can"},
        {title = "be"},
        {title = "changed"},
        {title = "as", onSelect = function() croppingDemo:visualSize(7) end},
        {title = "here.", onSelect = function() croppingDemo:visualSize(13) end},
        {title = "Now"},
        {title = "the"},
        {title = "list"},
        {title = "visual"},
        {title = "size"},
        {title = "is"},
        {title = "13"},
        {title = "and"},
        {title = "you"},
        {title = "can"},
        {title = "see"},
        {title = "more"},
        {title = "actions"},
        {title = "at"},
        {title = "once.", onSelect = function() croppingDemo:visualSize(13) end}
    })

appearanceDemo = page:newActionList()
    :title("Appearance")
    :color(vec(1, 0.5, 0.5))
    :hoverColor(vec(1, 0.75, 0.75))
    :item("axolotl_bucket")
    :actionList({
        {
            title = "Left click me!",
            onLeftClick = function()
                log("Hello! As you can understand, this button demonstrates the capabilities of the appearance of Action Lists. Let's run through them, left click on the next action")
            end
        },
        {
            title = '"The defaults"',
            onLeftClick = function()
                log('As you can see, this button has a "pink"(255, 127, 127) color in the standard state. But, each action can set its own color for the button. Navigate to the next action')
            end
        },
        {
            title = "Select me!",
            color = vec(0, 0, 1),
            hoverColor = vec(0.5, 0.5, 1),
            onSelect = function()
                log("Now the button background is blue! But it is only like this while this action is selected. Once the carriage exits this action, the background will turn pink again. Left click on the next action")
            end
        },
        {
            title = "But it's not just about color...",
            item = "minecraft:pufferfish_bucket",
            onLeftClick = function()
                log("But it's not just about color. You can also change the item/texture on the icon.")
            end
        },
        {
            title = "Left click me!",
            onLeftClick = function()
                log("And that's not all!! You can find more information about the appearance of the lists on the wiki!")
            end
        }
    })

functionalityDemo = page:newActionList()
    :title("Functionality")
    :item("minecraft:command_block")
    :actionList({
        {
            title = "Left click me!",
            onLeftClick = function()
                log("To be honest, there is not that much to say. There are not many differences in the functionality of action lists and just actions.")
            end
        },
        {
            title = "But there is one thing...",
            onSelect = function()
                log("But there is one thing: Because actions are selected by scrolling. Actions here do not have an onScroll function :(")
            end
        },
        {
            title = "But there is also one addition..",
            onSelect = function()
                log("But there is also one addition: Instead of onScroll there is onSelect function. This function is executes whenever the user navigates to an action that contains this function")
            end
        }
    })